(function(){window.__sfContentInjected||(window.__sfContentInjected=!0);let h=null,x=null,E=!1,T=0,I=0,D=null;chrome.runtime.onMessage.addListener((s,p,f)=>{if(s.action==="startAreaSelect")return D=s.dataUrl,$(),f({success:!0}),!0});function $(){if(h)return;h=document.createElement("div"),h.id="sf-ql-overlay",h.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.4);
    z-index: 2147483646;
    cursor: crosshair;
  `,x=document.createElement("div"),x.id="sf-ql-selection",x.style.cssText=`
    position: fixed;
    border: 2px solid #00A1E0;
    background: rgba(0, 161, 224, 0.1);
    pointer-events: none;
    z-index: 2147483647;
    display: none;
    box-sizing: border-box;
  `;const s=document.createElement("div");s.id="sf-ql-tip",s.textContent=chrome.i18n.getMessage("qrSelectTip")||"拖拽选择二维码区域，按 ESC 取消",s.style.cssText=`
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.75);
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    pointer-events: none;
  `,h.appendChild(x),h.appendChild(s),document.body.appendChild(h),E=!1,h.addEventListener("mousedown",P),h.addEventListener("mousemove",q),h.addEventListener("mouseup",R),document.addEventListener("keydown",_)}function P(s){s.button===0&&(s.preventDefault(),E=!0,T=s.clientX,I=s.clientY,x.style.display="block",x.style.left=T+"px",x.style.top=I+"px",x.style.width="0px",x.style.height="0px")}function q(s){if(!E)return;s.preventDefault();const p=Math.max(0,Math.min(window.innerWidth,s.clientX)),f=Math.max(0,Math.min(window.innerHeight,s.clientY)),a=Math.min(T,p),g=Math.min(I,f),v=Math.abs(p-T),b=Math.abs(f-I);x.style.left=a+"px",x.style.top=g+"px",x.style.width=v+"px",x.style.height=b+"px"}async function R(s){if(!E)return;s.preventDefault(),E=!1;const p=x.getBoundingClientRect(),f=p.left,a=p.top,g=p.width,v=p.height;if(B(),g<10||v<10){chrome.runtime.sendMessage({action:"areaCancelled",reason:"too small"});return}try{const b=await z(D,f,a,g,v);chrome.runtime.sendMessage({action:"areaSelected",dataUrl:b})}catch(b){chrome.runtime.sendMessage({action:"areaCancelled",reason:b.message})}}function _(s){s.key==="Escape"&&(B(),chrome.runtime.sendMessage({action:"areaCancelled",reason:"user cancelled"}))}function B(){E=!1,h&&h.parentNode&&h.parentNode.removeChild(h),h=null,x=null,document.removeEventListener("keydown",_)}function z(s,p,f,a,g){return new Promise((v,b)=>{const t=new Image;t.onload=()=>{const u=t.width/window.innerWidth,i=t.height/window.innerHeight,y=document.createElement("canvas");y.width=a*u,y.height=g*i,y.getContext("2d").drawImage(t,p*u,f*i,a*u,g*i,0,0,y.width,y.height),v(y.toDataURL("image/png"))},t.onerror=()=>b(new Error(chrome.i18n.getMessage("imageLoadFailed")||"图片加载失败")),t.src=s})}(function(){if(window.__sfPasskeyBridgeInjected)return;window.__sfPasskeyBridgeInjected=!0;const s="[CT]";function p(t,u){window.postMessage({source:"sf-extension",requestId:t,data:u},"*")}window.addEventListener("message",async t=>{if(!t.data||t.data.source!=="sf-page-world")return;const u=t.data.action,i=t.data.requestId;if(u==="sessionGet"){try{const e=await chrome.runtime.sendMessage({action:"__sf_sessionGet",keys:t.data.data.keys||t.data.keys});p(i,e||{})}catch(e){console.error(`${s} [sessionGet] 失败:`,e.message),p(i,{})}return}if(u==="sf:passkeyGet"||u==="sf:passkeyCreate"){let w=function(c){d||n||(d=!0,n=!0,o&&(clearInterval(o),o=null),b(),f.delete(i),console.warn(`${s} [${e}] 立即 fallback 系统 Passkey: ${c||""}`),p(i,{fallback:!0}))},m=function(){d||n||chrome.runtime.sendMessage({action:"bg:ping"}).then(c=>{d||n||c&&c.open&&(chrome.runtime.sendMessage({action:e,requestId:i,data:r}).catch(l=>{w(`send ${e} 失败: ${(l==null?void 0:l.message)||String(l)}`)}),n=!0,o&&(clearInterval(o),o=null))}).catch(c=>{w(`bg:ping 失败: ${(c==null?void 0:c.message)||String(c)}`)})};var y=w,k=m;const e=u,r=t.data.data;let d=!1,n=!1,o=null;m();const L=setTimeout(()=>{d||n||(v(),o=setInterval(m,3e3))},2e3);f.set(i,()=>{d=!0,clearTimeout(L),o&&clearInterval(o),b()});return}console.error(`${s} [message] 未处理的消息: ${u}`)}),chrome.runtime.onMessage.addListener((t,u)=>{if(t.action!=="sf:passkeyResult")return;const i=f.get(t.requestId);i&&(i(),f.delete(t.requestId)),p(t.requestId,t.data)});const f=new Map;let a=null,g=null;function v(){if(a)return;if(!document.getElementById("sf-bubble-style")){const m=document.createElement("style");m.id="sf-bubble-style",m.textContent=`
        @keyframes sf-bubble-in {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes sf-bubble-out {
          from { opacity: 1; transform: translateX(0); }
          to { opacity: 0; transform: translateX(20px); }
        }
        #sf-passkey-bubble.sf-closing {
          animation: sf-bubble-out 0.3s ease forwards;
        }
      `,document.head.appendChild(m)}a=document.createElement("div"),a.id="sf-passkey-bubble",a.style.cssText=`
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      background: #fff;
      border: 1px solid #1976d2;
      border-radius: 10px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.18);
      padding: 0;
      width: 300px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 13px;
      color: #333;
      overflow: hidden;
      animation: sf-bubble-in 0.3s ease;
    `;const t=document.createElement("div");t.style.cssText=`
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      background: linear-gradient(135deg, #1565c0, #1976d2);
      color: #fff;
    `;const u=chrome.runtime.getURL("icons/icon48.png");t.innerHTML=`
      <div style="width:22px;height:22px;border-radius:4px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        <img src="${u}" style="width:16px;height:16px;" alt="ext"/>
      </div>
      <span style="font-weight:600;font-size:13px;">Salesforce Quick Login</span>
    `;const i=document.createElement("div");i.style.cssText="padding: 12px 14px;";const y=document.createElement("div");y.textContent=chrome.i18n.getMessage("passkeyBubbleTitle")||"需要打开扩展面板",y.style.cssText="font-weight: 600; color: #0d47a1; margin-bottom: 6px; font-size: 14px;";const k=document.createElement("div");k.textContent=chrome.i18n.getMessage("passkeyBubbleDesc")||"网页正在请求 Passkey 验证，请打开扩展侧边栏以完成验证。",k.style.cssText="color: #555; line-height: 1.5; margin-bottom: 10px;";const e=document.createElement("div");e.style.cssText=`
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 10px;
      background: #f0f7ff;
      border-radius: 6px;
      margin-bottom: 10px;
    `,e.innerHTML=`
      <div style="position:relative;width:28px;height:28px;flex-shrink:0;">
        <svg width="28" height="28" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="4" width="24" height="18" rx="2" fill="#e3f2fd" stroke="#1976d2" stroke-width="1"/>
          <rect x="2" y="4" width="24" height="4" rx="2" fill="#bbdefb"/>
          <circle cx="5.5" cy="6" r="0.8" fill="#1976d2"/>
          <circle cx="8" cy="6" r="0.8" fill="#1976d2"/>
          <circle cx="10.5" cy="6" r="0.8" fill="#1976d2"/>
        </svg>
        <div style="position:absolute;top:-3px;right:-3px;width:12px;height:12px;border-radius:50%;background:#ff6f00;border:1.5px solid #fff;box-shadow:0 0 4px rgba(255,111,0,0.5);"></div>
      </div>
      <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
        <path d="M3 8 L13 8 M9 4 L13 8 L9 12" stroke="#1976d2" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <div style="width:28px;height:28px;flex-shrink:0;border-radius:6px;background:#fff;border:1.5px solid #1976d2;display:flex;align-items:center;justify-content:center;">
        <img src="${u}" style="width:18px;height:18px;" alt="ext"/>
      </div>
      <span style="font-size:11px;color:#1976d2;font-weight:500;">${chrome.i18n.getMessage("passkeyBubbleClickIcon")||"点击图标"}</span>
    `,i.appendChild(y),i.appendChild(k),i.appendChild(e);const r=document.createElement("div");r.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 14px;
      background: #fafafa;
      border-top: 1px solid #eee;
    `;const d=document.createElement("span");d.style.cssText="font-size: 11px; color: #999;";const n=document.createElement("button");n.textContent=chrome.i18n.getMessage("passkeyBubbleClose")||"关闭",n.style.cssText=`
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 12px;
      color: #1976d2;
      font-weight: 500;
      padding: 2px 8px;
    `,n.onmouseover=()=>{n.style.color="#0d47a1"},n.onmouseout=()=>{n.style.color="#1976d2"},n.onclick=b,r.appendChild(d),r.appendChild(n),a.appendChild(t),a.appendChild(i),a.appendChild(r),document.body.appendChild(a);const o=m=>chrome.i18n.getMessage("passkeyBubbleCountdown",[String(m)])||`${m}s 后自动关闭`;let w=30;d.textContent=o(w),g=setInterval(()=>{w--,w<=0?b():d.textContent=o(w)},1e3)}function b(){if(g&&(clearInterval(g),g=null),a){a.classList.add("sf-closing");const t=a;setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t)},300),a=null}}console.log(`${s} ========== 桥接模块初始化完成 (v4.1) ==========`)})();(function(){if(window!==window.top||window.__sfToolFloatRailInjected)return;window.__sfToolFloatRailInjected=!0;const p="sf-ql-tool-float-rail",f="sfql_tool_float_pos",a=5;function g(e,r){try{return chrome.i18n.getMessage(e)||r}catch{return r}}function v(e){chrome.runtime.sendMessage({action:"openToolWindow",toolId:e,hostname:location.hostname||""},()=>{chrome.runtime.lastError})}function b(){return new Promise(e=>{try{chrome.storage.local.get(f,r=>{if(chrome.runtime.lastError){e(null);return}e((r==null?void 0:r[f])||null)})}catch{e(null)}})}function t(e){try{chrome.storage.local.set({[f]:e},()=>{chrome.runtime.lastError})}catch{}}function u(e,r,d){const n=d.offsetWidth||28,o=d.offsetHeight||200,w=Math.max(8,window.innerHeight-o-8),m=Math.max(0,window.innerWidth-n-8);return{top:Math.min(Math.max(8,e),w),right:Math.min(Math.max(0,r),m)}}function i(e,r){if(!r||typeof r.top!="number"||typeof r.right!="number"){e.style.top="50%",e.style.right="0",e.style.left="auto",e.style.bottom="auto",e.style.transform="translateY(-50%)";return}const d=u(r.top,r.right,e);e.style.top=`${d.top}px`,e.style.right=`${d.right}px`,e.style.left="auto",e.style.bottom="auto",e.style.transform="none"}function y(){if(document.getElementById(p))return;const e=document.createElement("div");e.id=p,e.setAttribute("data-sf-ql","tool-float-rail"),e.style.cssText=["all: initial","position: fixed","top: 50%","right: 0","z-index: 2147483000","transform: translateY(-50%)","pointer-events: none",'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'].join(";");const r=e.attachShadow({mode:"open"});r.innerHTML=`
      <style>
        :host { all: initial; }
        .rail {
          display: flex;
          flex-direction: column;
          gap: 8px;
          pointer-events: none;
        }
        .tab {
          pointer-events: auto;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          min-height: 92px;
          padding: 12px 0;
          border: 1px solid transparent;
          border-right: none;
          border-radius: 10px 0 0 10px;
          cursor: grab;
          opacity: 0.48;
          box-shadow: -2px 2px 10px rgba(13, 71, 161, 0.14);
          transition: opacity 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease, filter 0.15s ease;
        }
        .tab:hover {
          opacity: 0.92;
          transform: translateX(-3px);
          box-shadow: -4px 3px 14px rgba(13, 71, 161, 0.28);
          filter: brightness(1.04);
        }
        .tab:active { cursor: grabbing; }
        .rail.is-dragging .tab {
          opacity: 0.85;
          cursor: grabbing;
          transition: none;
        }
        .text {
          writing-mode: vertical-rl;
          text-orientation: mixed;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.12em;
          line-height: 1;
          user-select: none;
          pointer-events: none;
        }
        .apex {
          background: linear-gradient(180deg, #0277bd 0%, #01579b 100%);
          border-color: #4fc3f7;
          color: #e1f5fe;
        }
        .apex:hover { color: #fff; }
        .soql {
          background: linear-gradient(180deg, #f9a825 0%, #ef6c00 100%);
          border-color: #ffe082;
          color: #fff8e1;
        }
        .soql:hover { color: #fff; }
      </style>
      <div class="rail" part="rail">
        <button type="button" class="tab apex" data-tool="apex-log" title="${g("toolFloatApexTitle","Apex Log Viewer")}">
          <span class="text">${g("toolFloatApex","Apex Log")}</span>
        </button>
        <button type="button" class="tab soql" data-tool="soql" title="${g("toolFloatSoqlTitle","SOQL Creator")}">
          <span class="text">${g("toolFloatSoql","SOQL")}</span>
        </button>
      </div>
    `;const d=r.querySelector(".rail");let n=null,o=null;b().then(c=>{o=c,i(e,o)});const w=c=>{if(!n)return;const l=c.clientX-n.startX,C=c.clientY-n.startY;if(!n.moved&&(Math.abs(l)>a||Math.abs(C)>a)&&(n.moved=!0,d.classList.add("is-dragging")),!n.moved)return;c.preventDefault();const M=u(n.originTop+C,n.originRight-l,e);i(e,M),n.current=M},m=c=>{if(!n)return;const l=n;if(n=null,window.removeEventListener("pointermove",w,!0),window.removeEventListener("pointerup",m,!0),window.removeEventListener("pointercancel",m,!0),d.classList.remove("is-dragging"),l.moved){l.current&&(o=l.current,t(o));return}l.toolId&&v(l.toolId)};d.querySelectorAll(".tab").forEach(c=>{c.addEventListener("pointerdown",l=>{if(l.button!==0)return;l.preventDefault(),l.stopPropagation();const C=e.getBoundingClientRect(),M=o&&typeof o.top=="number"?o.top:C.top,S=o&&typeof o.right=="number"?o.right:Math.max(0,window.innerWidth-C.right);i(e,{top:M,right:S}),n={startX:l.clientX,startY:l.clientY,originTop:M,originRight:S,moved:!1,toolId:c.getAttribute("data-tool"),current:{top:M,right:S}},window.addEventListener("pointermove",w,!0),window.addEventListener("pointerup",m,!0),window.addEventListener("pointercancel",m,!0)}),c.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation()})}),window.addEventListener("resize",()=>{o&&(o=u(o.top,o.right,e),i(e,o),t(o))});const L=()=>{!document.documentElement||document.getElementById(p)||document.documentElement.appendChild(e)};document.documentElement?L():document.addEventListener("DOMContentLoaded",L,{once:!0})}y();const k=()=>{try{y()}catch{}};setInterval(k,3e3),document.addEventListener("DOMContentLoaded",k,{once:!0})})();
})()
